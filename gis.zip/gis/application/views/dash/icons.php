<!DOCTYPE html>
<html lang="en">
  <head>
    <title>AdminX - Icons</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="../../assets/css/adminx.css" media="screen" />

    <!-- this is only relevant for the demo -->
    <link rel="stylesheet" href="../../assets/demo.css">
  </head>
  <body>
    <!-- expand-hover push -->
    <div class="adminx-sidebar expand-hover push" id="sidebar">
      <div class="adminx-sidebar-brand pl-4">
        <a class="navbar-brand mb-0 h1" href="index.php">
          <img src="../../assets/img/logo.png" class="navbar-brand-image d-inline-block align-top mr-2" alt="">
          AdminX
        </a>
      </div>

      <ul class="sidebar-nav">
        <li class="sidebar-nav-item">
          <a href="index.php" class="sidebar-nav-link">
            <span class="sidebar-nav-icon">
              <i data-feather="home"></i>
            </span>
            <span class="sidebar-nav-name">
              Dashboard
            </span>
            <span class="sidebar-nav-end">

            </span>
          </a>
        </li>

        <li class="sidebar-nav-item">
          <a href="#" class="sidebar-nav-link">
            <span class="sidebar-nav-icon">
              <i data-feather="layout"></i>
            </span>
            <span class="sidebar-nav-name">
              Layout Options
            </span>
            <span class="sidebar-nav-end">
              <span class="badge badge-info">4</span>
            </span>
          </a>
        </li>

        <li class="sidebar-nav-item">
          <a class="sidebar-nav-link collapsed" data-toggle="collapse" href="#example" aria-expanded="false" aria-controls="example">
            <span class="sidebar-nav-icon">
              <i data-feather="pie-chart"></i>
            </span>
            <span class="sidebar-nav-name">
              Charts
            </span>
            <span class="sidebar-nav-end">
              <i data-feather="chevron-right" class="nav-collapse-icon"></i>
            </span>
          </a>

          <ul class="sidebar-sub-nav collapse" id="example">
            <li class="sidebar-nav-item">
              <a href="charts_chartjs.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Ch
                </span>
                <span class="sidebar-nav-name">
                  ChartJS
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="./charts_morris.html" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Mo
                </span>
                <span class="sidebar-nav-name">
                  Morris
                </span>
              </a>
            </li>
          </ul>
        </li>

        <li class="sidebar-nav-item">
          <a class="sidebar-nav-link collapsed" data-toggle="collapse" href="#navTables" aria-expanded="false" aria-controls="navTables">
            <span class="sidebar-nav-icon">
              <i data-feather="align-justify"></i>
            </span>
            <span class="sidebar-nav-name">
              Tables
            </span>
            <span class="sidebar-nav-end">
              <i data-feather="chevron-right" class="nav-collapse-icon"></i>
            </span>
          </a>

          <ul class="sidebar-sub-nav collapse" id="navTables">
            <li class="sidebar-nav-item">
              <a href="tables.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Re
                </span>
                <span class="sidebar-nav-name">
                  Regular Tables
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="tables_data.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Da
                </span>
                <span class="sidebar-nav-name">
                  Data Tables
                </span>
              </a>
            </li>
          </ul>
        </li>

        <li class="sidebar-nav-item">
          <a class="sidebar-nav-link collapsed" data-toggle="collapse" href="#navForms" aria-expanded="false" aria-controls="navForms">
            <span class="sidebar-nav-icon">
              <i data-feather="edit"></i>
            </span>
            <span class="sidebar-nav-name">
              Forms
            </span>
            <span class="sidebar-nav-end">
              <i data-feather="chevron-right" class="nav-collapse-icon"></i>
            </span>
          </a>

          <ul class="sidebar-sub-nav collapse" id="navForms">
            <li class="sidebar-nav-item">
              <a href="form_elements.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  El
                </span>
                <span class="sidebar-nav-name">
                  Elements
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="form_advanced.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Ad
                </span>
                <span class="sidebar-nav-name">
                  Advanced Elements
                </span>
              </a>
            </li>
          </ul>
        </li>

        <li class="sidebar-nav-item">
          <a class="sidebar-nav-link" data-toggle="collapse" href="#navUI" aria-expanded="false" aria-controls="navUI">
            <span class="sidebar-nav-icon">
              <i data-feather="grid"></i>
            </span>
            <span class="sidebar-nav-name">
              UI Elements
            </span>
            <span class="sidebar-nav-end">
                  <i data-feather="chevron-right" class="nav-collapse-icon"></i>
            </span>
          </a>

          <ul class="sidebar-sub-nav collapse show" id="navUI">
            <li class="sidebar-nav-item">
              <a href="./icons.php" class="sidebar-nav-link active">
                <span class="sidebar-nav-abbr">
                  Ic
                </span>
                <span class="sidebar-nav-name">
                  Icons
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="buttons.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Bu
                </span>
                <span class="sidebar-nav-name">
                  Buttons
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="notifications.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  No
                </span>
                <span class="sidebar-nav-name">
                  Notifications
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="progress.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Pr
                </span>
                <span class="sidebar-nav-name">
                  Progress Bars
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="tabs.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Ta
                </span>
                <span class="sidebar-nav-name">
                  Tabs
                </span>
              </a>
            </li>
          </ul>
        </li>

        <li class="sidebar-nav-item">
          <a class="sidebar-nav-link collapsed" data-toggle="collapse" href="#navExtra" aria-expanded="false" aria-controls="navExtra">
            <span class="sidebar-nav-icon">
              <i data-feather="layers"></i>
            </span>
            <span class="sidebar-nav-name">
              Other Layouts
            </span>
            <span class="sidebar-nav-end">
              <i data-feather="chevron-right" class="nav-collapse-icon"></i>
            </span>
          </a>

          <ul class="sidebar-sub-nav collapse" id="navExtra">
            <li class="sidebar-nav-item">
              <a href="login.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Lo
                </span>
                <span class="sidebar-nav-name">
                  Login
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="./signup.html" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Si
                </span>
                <span class="sidebar-nav-name">
                  Sign Up
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="404.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Nf
                </span>
                <span class="sidebar-nav-name">
                  404 Error
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="500.php" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Is
                </span>
                <span class="sidebar-nav-name">
                  500 Error
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="./timeline.html" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  Ti
                </span>
                <span class="sidebar-nav-name">
                  Timeline
                </span>
              </a>
            </li>

            <li class="sidebar-nav-item">
              <a href="./invoice.html" class="sidebar-nav-link">
                <span class="sidebar-nav-abbr">
                  In
                </span>
                <span class="sidebar-nav-name">
                  Invoice
                </span>
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </div>

    <div class="adminx-container">
      <!-- Header -->
      <nav class="navbar navbar-expand justify-content-between fixed-top">
        <a class="navbar-brand mb-0 h1 d-none d-md-block" href="index.php">
          <img src="../../assets/img/logo.png" class="navbar-brand-image d-inline-block align-top mr-2" alt="">
          AdminX
        </a>

        <form class="form-inline form-quicksearch d-none d-md-block mx-auto">
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-icon">
                <i data-feather="search"></i>
              </div>
            </div>
            <input type="text" class="form-control" id="search" placeholder="Type to search...">
          </div>
        </form>

        <div class="d-flex flex-1 d-block d-md-none">
          <a href="#" class="sidebar-toggle ml-3">
            <i data-feather="menu"></i>
          </a>
        </div>

        <ul class="navbar-nav d-flex justify-content-end mr-2">
          <!-- Notificatoins -->
          <li class="nav-item dropdown d-flex align-items-center mr-2">
            <a class="nav-link nav-link-notifications" id="dropdownNotifications" data-toggle="dropdown" href="#">
              <i class="oi oi-bell display-inline-block align-middle"></i>
              <span class="nav-link-notification-number">3</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right dropdown-menu-notifications" aria-labelledby="dropdownNotifications">
              <div class="notifications-header d-flex justify-content-between align-items-center">
                <span class="notifications-header-title">
                  Notifications
                </span>
                <a href="#" class="d-flex"><small>Mark all as read</small></a>
              </div>

              <div class="list-group">
                <a href="#" class="list-group-item list-group-item-action unread">
                  <p class="mb-1">Invitation for <strong>Lunch</strong> on <strong>Jan 12th 2018</strong> by <strong>Laura</strong></p>

                  <div class="mb-1">
                    <button type="button" class="btn btn-primary btn-sm">Accept invite</button>
                    <button type="button" class="btn btn-outline-danger btn-sm">Decline</button>
                  </div>

                  <small>1 hour ago</small>
                </a>

                <a href="#" class="list-group-item list-group-item-action">
                  <p class="mb-1"><strong class="text-success">Goal completed</strong><br />1,000 new members today</p>
                  <small>3 days ago</small>
                </a>

                <a href="#" class="list-group-item list-group-item-action">
                  <p class="mb-1 text-danger"><strong>System error detected</strong></p>
                  <small>3 days ago</small>
                </a>

                <a href="#" class="list-group-item list-group-item-action">
                  <p class="mb-1">Your task <strong>Design Draft</strong> is due today.</p>
                  <small>4 days ago</small>
                </a>
              </div>

              <div class="notifications-footer text-center">
                <a href="#"><small>View all notifications</small></a>
              </div>
            </div>
          </li>
          <!-- Notifications -->
          <li class="nav-item dropdown">
            <a class="nav-link avatar-with-name" id="navbarDropdownMenuLink" data-toggle="dropdown" href="#">
              <img src="https://s3.amazonaws.com/uifaces/faces/twitter/jsa/128.jpg" class="d-inline-block align-top" alt="">
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="#">My Profile</a>
              <a class="dropdown-item" href="#">My Tasks</a>
              <a class="dropdown-item" href="#">Settings</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item text-danger" href="#">Sign out</a>
            </div>
          </li>
        </ul>
      </nav>
      <!-- // Header -->

      <!-- Main Content -->
      <div class="adminx-content">
        <div class="adminx-main-content">
          <div class="container-fluid">
            <!-- BreadCrumb -->
            <nav aria-label="breadcrumb" role="navigation">
              <ol class="breadcrumb adminx-page-breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">UI Elements</a></li>
                <li class="breadcrumb-item active  aria-current="page">Icons</li>
              </ol>
            </nav>

            <div class="pb-3">
              <h1>Icons</h1>
            </div>


            <div class="row">
              <div class="col">
                 <div class="card mb-grid text-center">
                  <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" id="card-tab-1" data-toggle="tab" href="#card-tab-content-1" role="tab" aria-controls="card-tab-content-1" aria-selected="true">Iconic</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" id="card-tab-2" data-toggle="tab" href="#card-tab-content-2" role="tab" aria-controls="card-tab-1" aria-selected="false">Feather</a>
                      </li>
                    </ul>
                  </div>
                  <div class="card-body">
                    <div class="tab-content">
                      <div class="tab-pane fade show active" id="card-tab-content-1" role="tabpanel" aria-labelledby="card-tab-1">
                        <div class="demo-icons">
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-account-login"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              account-login
                            </div>
                          </div>

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-account-logout"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              account-logout
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-action-redo"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              action-redo
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-action-undo"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              action-undo
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-align-center"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              align-center
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-align-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              align-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-align-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              align-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-aperture"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              aperture
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-bottom"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-bottom
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-circle-bottom"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-circle-bottom
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-circle-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-circle-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-circle-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-circle-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-circle-top"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-circle-top
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-thick-bottom"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-thick-bottom
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-thick-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-thick-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-thick-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-thick-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-thick-top"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-thick-top
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-top"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-top
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-arrow-top"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-top
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-audio-spectrum"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              audio-spectrum
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-audio"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              audio
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-badge"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              badge
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-ban"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              ban
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-bar-chart"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bar-chart
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-basket"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              basket
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-battery-empty"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              battery-empty
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-battery-full"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              battery-full
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-beaker"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              beaker
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-bell"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bell
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-bluetooth"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bluetooth
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-bold"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bold
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-bolt"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bolt
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-book"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              book
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-bookmark"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bookmark
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-box"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              box
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-briefcase"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              briefcase
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-british-pound"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              british-pound
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-browser"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              browser
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-brush"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              brush
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-bug"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bug
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-bullhorn"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bullhorn
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-calculator"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              calculator
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-calendar"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              calendar
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-camera-slr"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              camera-slr
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-caret-bottom"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              caret-bottom
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-caret-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              caret-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-caret-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              caret-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-caret-top"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              caret-top
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-cart"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cart
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-chat"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chat
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-check"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              check
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-chevron-bottom"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevron-bottom
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-chevron-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevron-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-chevron-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevron-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-chevron-top"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevron-top
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-circle-check"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              circle-check
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-circle-x"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              circle-x
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-clipboard"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              clipboard
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-clock"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              clock
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-cloud-download"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloud-download
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-cloud-upload"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloud-upload
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-cloud"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloud
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-cloudy"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloudy
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-code"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              code
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-cog"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cog
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-collapse-down"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              collapse-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-collapse-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              collapse-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-collapse-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              collapse-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-collapse-up"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              collapse-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-command"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              command
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-comment-square"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              comment-square
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-compass"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              compass
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-contrast"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              contrast
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-copywriting"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              copywriting
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-credit-card"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              credit-card
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-crop"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              crop
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-dashboard"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              dashboard
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-data-transfer-download"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              data-transfer-download
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-data-transfer-upload"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              data-transfer-upload
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-delete"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              delete
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-dial"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              dial
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-document"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              document
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-dollar"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              dollar
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-double-quote-sans-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              double-quote-sans-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-double-quote-sans-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              double-quote-sans-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-double-quote-serif-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              double-quote-serif-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-double-quote-serif-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              double-quote-serif-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-droplet"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              droplet
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-eject"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              eject
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-elevator"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              elevator
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-ellipses"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              ellipses
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-envelope-closed"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              envelope-closed
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-envelope-open"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              envelope-open
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-euro"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              euro
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-excerpt"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              excerpt
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-expand-down"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              expand-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-expand-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              expand-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-expand-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              expand-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-expand-up"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              expand-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-external-link"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              external-link
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-eye"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              eye
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-eyedropper"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              eyedropper
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-file"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              file
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-fire"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              fire
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-flag"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              flag
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-flash"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              flash
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-folder"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              folder
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-fork"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              fork
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-fullscreen-enter"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              fullscreen-enter
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-fullscreen-exit"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              fullscreen-exit
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-globe"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              globe
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-graph"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              graph
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-grid-four-up"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              grid-four-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-grid-three-up"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              grid-three-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-grid-two-up"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              grid-two-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-hard-drive"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              hard-drive
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-header"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              header
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-headphones"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              headphones
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-heart"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              heart
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-home"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              home
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-image"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              image
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-inbox"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              inbox
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-infinity"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              infinity
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-info"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              info
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-italic"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              italic
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-justify-center"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              justify-center
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-justify-left"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              justify-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-justify-right"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              justify-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-key"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              key
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-laptop"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              laptop
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-layers"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              layers
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-lightbulb"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              lightbulb
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-link-broken"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              link-broken
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-link-intact"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              link-intact
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-list-rich"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              list-rich
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-list"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              list
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-location"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              location
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-lock-locked"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              lock-locked
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-lock-unlocked"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              lock-unlocked
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-loop-circular"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              loop-circular
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-loop-square"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              loop-square
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-loop"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              loop
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-magnifying-glass"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              magnifying-glass
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-map-marker"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              map-marker
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-map"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              map
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-media-pause"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              media-pause
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-media-play"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              media-play
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-media-record"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              media-record
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-media-skip-backward"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              media-skip-backward
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-media-skip-forward"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              media-skip-forward
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-media-step-backward"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              media-step-backward
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-media-step-forward"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              media-step-forward
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-media-stop"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              media-stop
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-medical-cross"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              medical-cross
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-menu"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              menu
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-microphone"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              microphone
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-minus"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              minus
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-monitor"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              monitor
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-moon"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              moon
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-move"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              move
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-musical-note"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              musical-note
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-paperclip"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              paperclip
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-pencil"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              pencil
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-people"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              people
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-person"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              person
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-phone"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              phone
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-pie-chart"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              pie-chart
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-pin"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              pin
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-play-circle"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              play-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-plus"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              plus
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-power-standby"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              power-standby
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-print"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              print
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-project"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              project
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-pulse"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              pulse
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-puzzle-piece"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              puzzle-piece
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-question-mark"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              question-mark
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-rain"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              rain
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-random"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              random
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-reload"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              reload
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-resize-both"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              resize-both
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-resize-height"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              resize-height
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-resize-width"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              resize-width
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-rss-alt"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              rss-alt
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-rss"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              rss
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-script"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              script
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-share-boxed"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              share-boxed
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-share"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              share
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-shield"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              shield
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-signal"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              signal
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-signpost"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              signpost
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-sort-ascending"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              sort-ascending
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-sort-descending"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              sort-descending
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-spreadsheet"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              spreadsheet
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-star"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              star
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-sun"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              sun
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-tablet"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              tablet
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-tag"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              tag
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-tags"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              tags
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-target"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              target
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-task"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              task
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-terminal"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              terminal
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-text"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              text
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-thumb-down"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              thumb-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-thumb-up"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              thumb-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-timer"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              timer
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-transfer"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              transfer
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-trash"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              trash
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-underline"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              underline
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-vertical-align-bottom"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              vertical-align-bottom
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-vertical-align-center"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              vertical-align-center
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-vertical-align-top"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              vertical-align-top
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-video"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              video
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-volume-high"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              volume-high
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-volume-low"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              volume-low
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-volume-off"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              volume-off
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-warning"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              warning
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-wifi"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              wifi
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-wrench"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              wrench
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-x"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              x
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-yen"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              yen
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-zoom-in"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              zoom-in
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <span class="oi oi-zoom-out"></span>
                            </div>
                            <div class="demo-icon-name text-muted">
                              zoom-out
                            </div>
                          </div>
                          <!-- // Icon -->
                        </div>
                      </div>
                      <div class="tab-pane fade" id="card-tab-content-2" role="tabpanel" aria-labelledby="card-tab-2">
                        <div class="demo-icons">
                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="activity"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              activity
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="airplay"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              airplay
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="alert-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              alert-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="alert-octagon"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              alert-octagon
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="alert-triangle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              alert-triangle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="align-center"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              align-center
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="align-justify"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              align-justify
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="align-left"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              align-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="align-right"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              align-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="anchor"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              anchor
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="aperture"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              aperture
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="arrow-down-left"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-down-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="arrow-down-right"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-down-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="arrow-down"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="arrow-left"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="arrow-right"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="arrow-up-left"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-up-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="arrow-up-right"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-up-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="arrow-up"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              arrow-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="at-sign"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              at-sign
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="award"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              award
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="bar-chart-2"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bar-chart-2
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="bar-chart"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bar-chart
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="battery-charging"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              battery-charging
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="battery"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              battery
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="bell-off"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bell-off
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="bell"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bell
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="bluetooth"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bluetooth
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="bold"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bold
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="book"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              book
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="bookmark"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              bookmark
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="box"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              box
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="briefcase"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              briefcase
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="calendar"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              calendar
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="camera-off"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              camera-off
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="camera"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              camera
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="cast"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cast
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="check-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              check-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="check-square"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              check-square
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="check"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              check
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="chevron-down"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevron-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="chevron-left"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevron-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="chevron-right"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevron-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="chevron-up"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevron-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="chevrons-down"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevrons-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="chevrons-left"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevrons-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="chevrons-right"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevrons-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="chevrons-up"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chevrons-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="chrome"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              chrome
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="clipboard"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              clipboard
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="clock"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              clock
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="cloud-drizzle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloud-drizzle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="cloud-lightning"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloud-lightning
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="cloud-off"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloud-off
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="cloud-rain"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloud-rain
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="cloud-snow"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloud-snow
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="cloud"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cloud
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="codepen"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              codepen
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="command"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              command
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="compass"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              compass
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="copy"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              copy
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="corner-down-left"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              corner-down-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="corner-down-right"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              corner-down-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="corner-left-down"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              corner-left-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="corner-left-up"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              corner-left-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="corner-right-down"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              corner-right-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="corner-right-up"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              corner-right-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="corner-up-left"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              corner-up-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="corner-up-right"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              corner-up-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="cpu"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              cpu
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="credit-card"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              credit-card
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="crop"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              crop
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="crosshair"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              crosshair
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="delete"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              delete
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="disc"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              disc
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="download-cloud"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              download-cloud
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="download"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              download
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="droplet"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              droplet
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="edit-2"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              edit-2
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="edit-3"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              edit-3
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="edit"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              edit
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="external-link"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              external-link
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="eye-off"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              eye-off
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="eye"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              eye
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="facebook"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              facebook
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="fast-forward"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              fast-forward
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="feather"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              feather
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="file-minus"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              file-minus
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="file-plus"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              file-plus
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="file-text"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              file-text
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="file"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              file
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="film"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              film
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="filter"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              filter
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="flag"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              flag
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="folder"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              folder
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="github"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              github
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="gitlab"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              gitlab
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="globe"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              globe
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="grid"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              grid
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="hash"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              hash
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="headphones"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              headphones
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="heart"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              heart
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="help-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              help-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="home"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              home
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="image"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              image
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="inbox"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              inbox
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="info"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              info
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="instagram"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              instagram
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="italic"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              italic
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="layers"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              layers
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="layout"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              layout
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="life-buoy"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              life-buoy
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="link-2"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              link-2
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="link"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              link
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="list"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              list
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="lock"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              lock
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="log-in"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              log-in
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="log-out"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              log-out
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="mail"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              mail
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="map-pin"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              map-pin
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="map"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              map
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="maximize-2"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              maximize-2
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="maximize"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              maximize
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="menu"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              menu
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="message-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              message-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="message-square"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              message-square
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="mic-off"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              mic-off
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="mic"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              mic
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="minimize-2"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              minimize-2
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="minimize"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              minimize
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="minus-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              minus-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="minus-square"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              minus-square
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="minus"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              minus
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="monitor"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              monitor
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="moon"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              moon
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="more-horizontal"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              more-horizontal
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="more-vertical"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              more-vertical
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="move"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              move
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="music"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              music
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="navigation-2"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              navigation-2
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="navigation"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              navigation
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="octagon"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              octagon
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="package"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              package
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="paperclip"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              paperclip
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="pause-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              pause-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="pause"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              pause
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="percent"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              percent
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="phone-call"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              phone-call
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="phone-forwarded"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              phone-forwarded
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="phone-incoming"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              phone-incoming
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="phone-missed"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              phone-missed
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="phone-off"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              phone-off
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="phone-outgoing"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              phone-outgoing
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="phone"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              phone
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="pie-chart"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              pie-chart
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="play-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              play-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="play"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              play
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="plus-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              plus-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="plus-square"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              plus-square
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="plus"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              plus
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="pocket"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              pocket
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="power"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              power
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="printer"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              printer
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="radio"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              radio
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="refresh-ccw"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              refresh-ccw
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="refresh-cw"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              refresh-cw
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="repeat"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              repeat
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="rewind"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              rewind
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="rotate-ccw"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              rotate-ccw
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="rotate-cw"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              rotate-cw
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="save"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              save
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="scissors"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              scissors
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="search"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              search
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="server"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              server
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="settings"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              settings
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="share-2"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              share-2
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="share"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              share
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="shield"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              shield
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="shopping-cart"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              shopping-cart
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="shuffle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              shuffle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="sidebar"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              sidebar
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="skip-back"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              skip-back
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="skip-forward"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              skip-forward
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="slack"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              slack
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="slash"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              slash
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="sliders"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              sliders
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="smartphone"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              smartphone
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="speaker"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              speaker
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="square"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              square
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="star"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              star
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="stop-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              stop-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="sun"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              sun
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="sunrise"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              sunrise
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="sunset"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              sunset
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="tablet"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              tablet
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="tag"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              tag
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="target"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              target
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="thermometer"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              thermometer
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="thumbs-down"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              thumbs-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="thumbs-up"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              thumbs-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="toggle-left"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              toggle-left
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="toggle-right"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              toggle-right
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="trash-2"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              trash-2
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="trash"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              trash
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="trending-down"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              trending-down
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="trending-up"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              trending-up
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="triangle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              triangle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="tv"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              tv
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="twitter"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              twitter
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="type"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              type
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="umbrella"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              umbrella
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="underline"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              underline
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="unlock"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              unlock
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="upload-cloud"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              upload-cloud
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="upload"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              upload
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="user-check"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              user-check
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="user-minus"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              user-minus
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="user-plus"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              user-plus
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="user-x"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              user-x
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="user"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              user
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="users"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              users
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="video-off"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              video-off
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="video"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              video
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="voicemail"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              voicemail
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="volume-1"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              volume-1
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="volume-2"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              volume-2
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="volume-x"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              volume-x
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="volume"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              volume
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="watch"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              watch
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="wifi-off"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              wifi-off
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="wifi"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              wifi
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="wind"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              wind
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="x-circle"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              x-circle
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="x-square"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              x-square
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="x"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              x
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="zap"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              zap
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="zoom-in"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              zoom-in
                            </div>
                          </div>
                          <!-- // Icon -->

                          <!-- Icon -->
                          <div class="demo-icon">
                            <div class="demo-icon-display">
                              <i data-feather="zoom-out"></i>
                            </div>
                            <div class="demo-icon-name text-muted">
                              zoom-out
                            </div>
                          </div>
                          <!-- // Icon -->
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- // Main Content -->
    </div>

    <!-- If you prefer jQuery these are the required scripts -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor.js"></script>
    <script src="../../assets/js/adminx.js"></script>

    <!-- If you prefer vanilla JS these are the only required scripts -->
    <!-- script src="../dist/js/vendor.js"></script>
    <script src="../dist/js/adminx.vanilla.js"></script-->
  </body>
</html>
