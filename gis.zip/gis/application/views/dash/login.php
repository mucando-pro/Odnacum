<!DOCTYPE html>
<html lang="en">
  <head>
    <title>gis.network</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('')?>assets/dashAssets/css/adminx.css" media="screen" />
  </head>
  <body>
    <div class="adminx-container d-flex justify-content-center align-items-center">
      <div class="page-login">
        <!--<div class="text-center">
          <a class="navbar-brand mb-4 h1" href="login.php">
            <img src="<?php /*echo base_url('')*/?>assets/images/1.jpg" class="navbar-brand-image img-circle d-inline-block align-top mr-2" alt="logo" width="">
          </a>
        </div>-->

        <div class="card mb-0">
          <div class="card-body">
            <form id="formLogin">
              <div class="form-group">
                <input type="email" class="form-control" id="exampleDropdownFormEmail1" placeholder="email@exemplo.com">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" id="exampleDropdownFormPassword1" placeholder="Senha">
              </div>
              <div class="form-group">
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" id="customCheck1">
                  <label class="custom-control-label" for="customCheck1">Lembre-me</label>
                </div>
              </div>
<!--              <button type="submit" class="btn btn-sm btn-block btn-primary">Entrar</button>-->
				<a class="btn btn-sm btn-block btn-primary" id="btnLogin" href="#">Entrar</a>
				<!--<?php echo site_url('AppController/dash')?>-->
			</form>
			<div id="divprocesss">
			    
			</div>
          </div>
          <div class="card-footer text-center">
            <a href="#"><small>Esqueceu a senha</small></a>
          </div>
        </div>
      </div>
    </div>

    <!-- If you prefer jQuery these are the required scripts -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url('')?>assets/dashAssets/js/vendor.js"></script>
    <script src="<?php echo base_url('')?>assets/dashAssets/js/adminx.js"></script>

    <!-- If you prefer vanilla JS these are the only required scripts -->
    <!-- script src="../dist/js/vendor.js"></script>
    <script src="../dist/js/adminx.vanilla.js"></script-->
    
    <script type="text/javascript" >
		//alert("Login");

		$("#btnLogin").click(function(event) {
				event.preventDefault();
			
				//alert("cliclou ");
                email = $("#exampleDropdownFormEmail1").val();
				//gif = "<img src='../assets/img/unnamed.gif' alt='carregando' >";
				url="<?php echo site_url('UserController/login')?>";
				$.ajax({
					url:url,
					type:"POST",
					data: $('#formLogin').serialize(),
						beforeSend: function(){  
						alert("foi ");
					
						
						},
						success:function(data){
							//alert("voltou ");
							$("#divprocesss").html(data);
					   }
				}); 
			});

	</script>
    
    
    
  </body>
</html>
