<div class="foo">
	<footer class="footer-widget meuBo">
		<!--footer-top-->
		<div class="footer-widgets" id="footer">
			<div class="">
				<div class="row">
					<div class="col-md-5">
						<h4>Contactos</h4>
						<p class="text-left">
							<span><i class="fa fa-phone"></i>+258  870204768</span> <br>
							<strong>Localização:</strong> <span>Rua n. 7, Bairro do Estoril Cidade da Beira, Beira, 258, Mozambique</span>
						</p>
					</div>

					<div class="col-md-2 social">
						<span><a href=" https://www.facebook.com/gisnetwork.mz/" target="_blank"><i
										class="icon icon-social-facebook fa-2x"></i> </a></span>&nbsp;&nbsp;
						<span><a href="https://www.linkedin.com/company/gisnetwork-mz/" target="_blank"><i
										class="icon icon-social-linkedin fa-2x"></i> </a></span>&nbsp;&nbsp;
						<span><a href="https://www.instagram.com/gisnetwork.mz/" target="_blank"><i
										class="icon icon-social-instagram fa-2x"></i> </a></span>&nbsp;&nbsp;
						<span><a href="https://wa.me/258866391091 " target="_blank"><i class="fa fa-whatsapp fa-2x"></i> </a></span>
					</div>

					<div class="col-md-4">
						<h4>Receba novidades</h4>
						<a class="btn btn-primary btn-icon" href="#">Cadastrar-se </a>
					</div>
				</div>
			</div>
		</div>
		<!--footer copyright-->
		<div class="cta-area footer-copyright footer-bottom" style="background-color: #f7f7f7; height: 50px; ">

			<div class="cta-text text-center ">
				<div class="copyright" style="color: black">Copyright &copy; 2020. All Rights Reserved</div>
			</div>

		</div>
	</footer>
</div>

