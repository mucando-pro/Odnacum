<!doctype html>
<html class="no-js" lang="zxx">

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>gisNetwork</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Place favicon.ico in the root directory -->

	<!-- bootstrap v4.0.0 -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
	<!-- fontawesome-icons css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/font-awesome.min.css') ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/fonts.css') ?>">
	<!-- themify-icons css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/themify-icons.css') ?>">
	<!-- elegant css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/elegant.css') ?>">
	<!-- meanmenu css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/meanmenu.min.css') ?>">
	<!-- animate css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/animate.css') ?>">
	<!-- venobox css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/venobox.css') ?>">
	<!-- jquery-ui.min css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/jquery-ui.min.css') ?>">
	<!-- slick css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/slick.css') ?>">
	<!-- slick-theme css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/slick-theme.css') ?>">
	<!-- helper css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/helper.css') ?>">
	<!-- style css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style1.css') ?>">
	<!-- responsive css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/responsive.css') ?>">
	<!--    <link rel="stylesheet" href="--><?php //echo base_url('assets/css/atlantis.min.css')?><!--">-->
	<!--    <link rel="stylesheet" href="--><?php //echo base_url('assets/css/demo.css')?><!--">-->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/icons.css') ?>">


</head>

<body>
