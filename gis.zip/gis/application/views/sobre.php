<div class=" " style="background-color:#f7f7f7; margin-bottom: 2%!important;">
	<div class="container" style="font-size:12px">
		<a href="<?php echo site_url('appcontroller/index') ?>">Pagina inicial »<a/> Sobre
	</div>
</div>
<div class="service-details-area mt-100 sm-mt-80">
	<div class="container">
		<div class="offset-1">
			<div>

				<p>
					Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
					devido tempo. Estamos emsddpenhados em fornecer aos nossos clientes melhores serviços e produtos no
					devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
					devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
					devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
					devido tempo.
				</p>
				<a href="#" class="btn btn-success btn-sm bt"><span class="fa fa-envelope"></span> inscrever-se </a>
			</div>
			<hr>
			<div class="box">
				<div class="row">
					<div class="col-md-2 ">
						<img src="<?php echo base_url('assets/images/logo/gis.networklogo6.png') ?>" alt="">
					</div>
					<div class="col-md-10 text-justify">
						<h4> O que aconteceu?</h4>
							<p class="descricao">
								Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
								devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
								devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
								devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
								devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
								devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
								devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
								devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
								devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
								devido tempo.
							</p>
						<a href="#" class="btn btn-success btn-sm bt"><span class="fa fa-download"></span> baixar </a>
					</div>

					<div class="col-md-10 text-justify offset-2">
						<hr>
						<h4> Upx?</h4>
						<p class="descricao ">
							Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.
						</p>
						<a href="#" class="btn btn-success btn-sm bt"><span class="fa fa-download"></span> baixar </a>
					</div>
					<div class="col-md-10 text-justify offset-2">
						<hr>
						<h4> Upx?</h4>
						<p class="descricao ">
							Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
							devido tempo.
						</p>
						<a href="#" class="btn btn-success btn-sm bt"><span class="fa fa-download"></span> baixar </a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<hr>

