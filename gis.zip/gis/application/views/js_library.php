<script src="<?php echo base_url('assets/js/vendor/modernizr-3.6.0.min.js')?>"></script>
<!-- jquery-1.12.0 version -->
<script src="<?php echo base_url('assets/js/vendor/jquery-1.12.0.min.js')?>"></script>
<!-- bootstra.min js -->
<script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
<!-- meanmenu js -->
<script src="<?php echo base_url('assets/js/jquery.meanmenu.min.js')?>"></script>
<!-- easing js -->
<script src="<?php echo base_url('assets/js/jquery.easing.min.js')?>"></script>
<!---venobox-js-->
<script src="<?php echo base_url('assets/js/venobox.min.js')?>"></script>
<!---slick-js-->
<script src="<?php echo base_url('assets/js/slick.min.js')?>"></script>
<!---waypoints-js-->
<script src="<?php echo base_url('assets/js/waypoints.js')?>"></script>
<!---counterup-js-->
<script src="<?php echo base_url('assets/js/jquery.counterup.min.js')?>"></script>
<!---isotop-js-->
<script src="<?php echo base_url('assets/js/isotope.pkgd.min.js')?>"></script>
<!-- jquery-ui js -->
<script src="<?php echo base_url('assets/js/jquery-ui.min.js')?>"></script>
<!-- jquery.countdown js -->
<script src="<?php echo base_url('assets/js/jquery.countdown.min.js')?>"></script>
<!-- plugins js -->
<script src="<?php echo base_url('assets/js/plugins.js')?>"></script>
<!-- main js -->
<script src="<?php echo base_url('assets/js/main.js')?>"></script>
<script src="<?php echo base_url('assets/js/tooltip.js')?>"></script>
</body>
</html>
