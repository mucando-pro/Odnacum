<div class=" " style="background-color:#f7f7f7 ">
	<div class="container" style="font-size:12px">
		<a href="<?php echo site_url('appcontroller/index')?>" >Pagina inicial »<a/> Boletim
	</div>
</div>
<div class="container meuBo estiliza" >
	<div class="col-md-10">
		<div class="section-title text-left">
			<p class="text-justify" style="color: #929695">
				A gis.network, lda foi fundada em 2018 por dois especialistas em GIS
				(Sistemas de Informação Geográfica) na Beira, Moçambique. A gis.network, lda é uma empresa jovem
				e dinâmica, especializada em fornecer uma.
			</p>
			<a class="btn btn-success btn-sm bt" href="#" value="Entrar">
				<i class="fa fa-envelope"> </i> inscreva-se
			</a>
			<hr style="margin-top: 1.3%">
		</div>
	</div>
</div>

<div class="about-area mt-85 sm-mt-30 meuBo estiliza" id="boll " >
	<div class="container">
		<div class="row">
			<div class="col-md-2 text-center">
				<img src="<?php echo base_url('assets/images/logo/gis.networklogo6.png') ?>" alt="">
			</div>
			<div class="col-md-10">
				<div class="section-title text-left">
					<h2 class="titulos">Noticias</h2>

					<p class="text-justify" style="color: #929695">A gis.network, lda foi fundada em 2018 por dois especialistas em GIS
						(Sistemas de Informação Geográfica) na Beira, Moçambique. A gis.network, lda é uma empresa jovem
						e dinâmica, especializada em fornecer uma solução inteligente para resolver muitos dos problemas
						relacionados à agricultura, urbanização e meio ambiente (incluindo avaliação de riscos de
						desastres naturais) através da integração de conceitos de sistemas de informação geográfica
						(SIG). e abordagens de sensoriamento remoto (RS). A GIS.Network, Ltd tem a sua sede na província
						de Sofala - cidade da Beira, Moçambique.
					</p>
					<br>
					<hr style="margin-top: -1.5%">
				</div>
			</div>
		</div>
	</div>
</div>
