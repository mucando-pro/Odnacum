<!--END HEAD-->

<!--header-bottom-->
<?php
include_once __DIR__ . '/header.php';
?>
<!--header-area end-->

<!--banner-area start-->
<div class=" " style="background-color:#f7f7f7 ">
	<div class="container" style="font-size:12px">
		<a href="<?php echo site_url('appcontroller/index')?>" >Pagina inicial<a/>
	</div>
</div>
<!--banner-area end-->


<!--about-area start-->
<div class="about-area mt-85 sm-mt-30">
	<div class="container">
		<div class="row">
			<div class="col-md-2 text-center">
				<img src="<?php echo base_url('assets/images/logo/gis.networklogo6.png') ?>" alt="Logo" height="190">
			</div>
			<div class="col-md-10">
				<div class="section-title text-left">
					<h2 class="titulos">Quem nós somos</h2>
					<hr style="margin-top: -1.5%">
					<p class="text-justify" style="color: #929695">A gis.network, lda foi fundada em 2018 por dois especialistas em GIS
						(Sistemas de Informação Geográfica) na Beira, Moçambique. A gis.network, lda é uma empresa jovem
						e dinâmica, especializada em fornecer uma solução inteligente para resolver muitos dos problemas
						relacionados à agricultura, urbanização e meio ambiente (incluindo avaliação de riscos de
						desastres naturais) através da integração de conceitos de sistemas de informação geográfica
						(SIG). e abordagens de sensoriamento remoto (RS). A GIS.Network, Ltd tem a sua sede na província
						de Sofala - cidade da Beira, Moçambique.
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!--about-area end-->
<div class="cta-area mt-100">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12">
				<div class="cta-text text-center section-title offset-2">
					<h3>Subsistema gis.Network</h3>
				</div>
					<!-- <h3>gis.Network AGR</h3> -->
				<div class="row offset-1">
					<div class="col-md-3">
						<div class="sin-service style-2">
							<i class="icon-settings"></i>
							<h3>gis.Network AGR</h3>
							<p>
								<a class="btn btn-primary btn-sm bt" href="#" value="Entrar">
									Entrar »
								</a>
							</p>
						</div>
					</div>
					
					<div class="col-md-3">
						<div class="sin-service style-2">
							<i class="icon-globe"></i>
							<h3>gis.Network AMB</h3>
							<p>
								<a class="btn btn-primary btn-sm bt" href="#" value="Entrar">
									Entrar »
								</a>
							</p>
						</div>
					</div>
					<div class="col-md-3">
						<div class="sin-service style-2">
							<i class="icon-note"></i>
							<h3>gis.Network
								<URB></URB>
							</h3>
							<p>
								<a class="btn btn-primary btn-sm bt" href="#" value="Entrar">
									Entrar »
								</a>
							</p>
						</div>
					</div>
					<div class="col-md-3">
						<div class="sin-service style-2">
							<i class="icon-notebook"></i>
							<h3>Boletim gis.Network </h3>
							<p>
								<a class="btn btn-primary btn-sm bt" href="#" value="Entrar">
									Entrar »
								</a>
							</p>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
</div>

<div class="service-details-area mt-100 sm-mt-80">
	<div class="container">
		<div class="offset-1">
			<div class="row">
				<div class="box">
					<div class="row">
						<div class="col-md-4 zoom">
							<img src="<?php echo base_url('assets/images/logo/Sobre.png') ?>" alt="">
							<div class="conteudo">
								<h3 class="nome-secao">
									Sobre
								</h3>
							</div>
							<div class="text-capitalize testimonial-items">
								<p class="descricao">
									Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
									devido tempo.
								</p>
								<a href="" class="btn-more "> Mais»</a>
							</div>

						</div>
						<div class="col-md-4 zoom">
							<img src="<?php echo base_url('assets/images/logo/Actualizacoes.png') ?>" alt="">
							<div class="conteudo">
								<h3 class="nome-secao">
									Atualização
								</h3>
							</div>
							<div>
								<p class="descricao">
									Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
									devido tempo.
								</p>
								<a href="" class="btn-more"> Mais»</a>
							</div>

						</div>
						<div class="col-md-4 zoom">
							<img src="<?php echo base_url('assets/images/logo/Publicacoes.png') ?>" alt="">
							<div class="conteudo">
								<h3 class="nome-secao">
									Publicações
								</h3>
							</div>
							<div>
								<p class="descricao">
									Estamos empenhados em fornecer aos nossos clientes melhores serviços e produtos no
									devido tempo.
								</p>
								<a href="" class="btn-more"> Mais»</a>
							</div>

						</div>

					</div>


				</div>
			</div>

		</div>


	</div>
</div>
<hr>

