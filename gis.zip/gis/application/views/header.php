<header class="">
    <div id="sticker" class="header-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-sm-2">
                    <div class="logo">
                        <a href="i<?php echo site_url('AppController/index')?>"><img src="<?php echo base_url('assets/images/logo/gis.networklogo6.png') ?>" alt="Logo" height="50" class="img-circle"></a>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="mainmenu text-center " style="">
                        <nav>
                            <ul class="menu">
                                <li><a href="<?php echo site_url('AppController/index')?>" style=""class="active">Inicio</a>
                                </li>
                                <li><a href="<?php echo site_url('AppController/about')?>">Sobre</a>

                                </li>
                                <li><a href="<?php echo site_url('AppController/express')?>">Express</a>

                                </li>
                                <li><a href="<?php echo site_url('AppController/boletim')?>">Boletim</a>

                                </li>
                                <li><a href="<?php echo site_url('AppController/method')?>">Métodos</a>

                                </li>
                                <li><a href="<?php echo site_url('AppController/publish')?>">Publicações</a>
                                </li>
                                <li><a href="<?php echo site_url('AppController/contact')?>">Contactos</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="search-and-cart">
                        <!--search-box-->
                        <div class="search search-box">
                            <a href="<?php echo site_url('AppController/login')?>" style="color: inherit">Entrar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
