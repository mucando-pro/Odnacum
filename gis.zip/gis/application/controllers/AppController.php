<?php
defined('BASEPATH') or exit('No direct script access allowed');

class AppController extends CI_Controller
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 *        http://example.com/index.php/welcome
	 *    - or -
	 *        http://example.com/index.php/welcome/index
	 *    - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('head_bibliotecasCSS');
		$this->load->view('index');
		$this->load->view('footer');
		$this->load->view('js_library');

	}

	public function login()
	{
		$this->load->view('dash/login');
	}

	public function about()
	{
		$this->load->view('head_bibliotecasCSS');
		$this->load->view('header');
		$this->load->view('sobre');
		$this->load->view('footer');
		$this->load->view('js_library');
	}

	public function contact()
	{
		$this->load->view('head_bibliotecasCSS');
		$this->load->view('header');
		$this->load->view('contactos');
		/*	$this->load->view('footer');
			$this->load->view('js_library');*/
	}

	public function cadastro()
	{

	}

	public function AGR()
	{

	}

	public function AMB()
	{

	}

	public function URB()
	{

	}

	public function boletim()
	{
		$this->load->view('head_bibliotecasCSS');
		$this->load->view('header');
		$this->load->view('boletim');
		$this->load->view('footer');
		$this->load->view('js_library');


	}

	public function express()
	{
		$this->load->view('head_bibliotecasCSS');
		$this->load->view('header');
		$this->load->view('express');
		/*	$this->load->view('footer');
			$this->load->view('js_library');*/


	}

	public function services()
	{
		$this->load->view('head_bibliotecasCSS');
		$this->load->view('header');
		$this->load->view('servicos');
		/*$this->load->view('footer');
		$this->load->view('js_library');*/
	}

	public function updated()
	{
		$this->load->view('head_bibliotecasCSS');
		$this->load->view('header');
		$this->load->view('atualizacao');
		/*	$this->load->view('footer');
			$this->load->view('js_library');*/
	}

	public function publish()
	{
		$this->load->view('head_bibliotecasCSS');
		$this->load->view('header');
		$this->load->view('publicacoes');
		/*	$this->load->view('footer');
			$this->load->view('js_library');*/
	}

	public function method()
	{
		$this->load->view('head_bibliotecasCSS');
		$this->load->view('header');
		$this->load->view('metodos');
		/*	$this->load->view('footer');
			$this->load->view('js_library');*/
	}

	public function dash()
	{
		redirect('dash');
	}
}
